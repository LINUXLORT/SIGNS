close all; clear;clc;
%original = imread('ATBV51FNQW5O.jpg'); % Load original ColoredChips.png image
%original = imread('0IWYSA892WEA.jpg'); % Load original ColoredChips.png image
%original = imread('6B16XQW53PXG.jpg'); % Load original ColoredChips.png image
%original = imread('60C9UUWCS8UU.jpg'); % Load original ColoredChips.png image
original = imread('ZNLUJY4758VA.jpg'); % Load original ColoredChips.png image
gauss = fspecial("gaussian",10);
original = imadjust(original,[.2 .3 0; .6 .7 1],[]);
originalImage = imfilter(original,gauss);
[rows, columns, channels] = size(originalImage); % Get the dimensions of the image
if channels~=3
	error('the image needs to be RGB')
end
% Display the original images
subplot(2,1,1);
imshow(original);
subplot(2,1,2)
imshow(originalImage)
% instead of building all the masks first, let's just define the thresholds
hsvpict = originalImage;
thR = [170 255; 0 100; 0 100];
% thG = [0.402 0.453; 0.578 1; 0 1];
% thB = [0.578 0.642; 0.578 1; 0 1];
thO = [0.019 0.073; 0.578 1; 0 1];
% thY = [0.150 0.184; 0.578 1; 0 1];
% select the nominal chip color
% colormode = 'red';
% outpict = originalImage;
% switch lower(colormode)
%     case 'red'
%         selectedth = thR;
%     case 'green'
%         selectedth = thG;
%     case 'blue'
%         selectedth = thB;
%     case 'orange'
%         selectedth = thO;
%     case 'yellow'
%         selectedth = thY;
%     otherwise 
%         error('you got an error')
% end
selectedth = thR;
% make the selection as a closed box
selectedmask_raw = (hsvpict(:,:,1) >= selectedth(1,1)) & (hsvpict(:,:,1) <= selectedth(1,2)) & ...
                (hsvpict(:,:,2) >= selectedth(2,1)) & (hsvpict(:,:,2) <= selectedth(2,2)) & ...
                (hsvpict(:,:,3) >= selectedth(3,1)) & (hsvpict(:,:,3) <= selectedth(3,2));

imshow(selectedmask_raw);
%%

% selectedth = thO;
% % make the selection as a closed box
% selectedmask_raw_orange = (hsvpict(:,:,1) >= selectedth(1,1)) & (hsvpict(:,:,1) <= selectedth(1,2)) & ...
%                 (hsvpict(:,:,2) >= selectedth(2,1)) & (hsvpict(:,:,2) <= selectedth(2,2)) & ...
%                 (hsvpict(:,:,3) >= selectedth(3,1)) & (hsvpict(:,:,3) <= selectedth(3,2));
% 
% selectedmask_raw = selectedmask_raw_red | selectedmask_raw_orange;

% clean up selection to get rid of cross-selection in shadow areas
selectedmask_raw = bwareaopen(selectedmask_raw,100);
% if color replacement isn't needed, this simplifies
selectedmask = repmat(selectedmask_raw,[1 1 3]);
% outpict(selectedmask) = 0;
% 
% subplot(2,1,2);
% imshow(outpict);


figure
imshow(selectedmask_raw);

k = strel('disk',3);
full_image = imdilate(selectedmask_raw,k)
figure
imshow(full_image)
